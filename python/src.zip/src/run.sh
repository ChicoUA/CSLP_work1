#!/bin/bash
python src/utils.py
python src/drive_through.py
python src/cook.py
python src/deliver.py
python src/clerk_example.py
python src/client_example.py